"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 4074:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "server": () => (/* binding */ server)
});

;// CONCATENATED MODULE: external "msw/node"
const node_namespaceObject = require("msw/node");
;// CONCATENATED MODULE: external "msw"
const external_msw_namespaceObject = require("msw");
;// CONCATENATED MODULE: ./src/mocks/handlers.ts

// ** API SERVER START
// ** npx msw init ./public --save
const handlers = [
    external_msw_namespaceObject.rest.get("https://my.backend/book", (req, res, ctx)=>{
        return res(ctx.json({
            title: "Lord of the Rings",
            imageUrl: "/book-cover.jpg",
            description: "The Lord of the Rings is an epic high-fantasy novel written by English author and scholar J. R. R. Tolkien."
        }));
    }),
    external_msw_namespaceObject.rest.get("/reviews", (req, res, ctx)=>{
        return res(ctx.json([
            {
                id: "60333292-7ca1-4361-bf38-b6b43b90cb16",
                author: "John Maverick",
                text: "Lord of The Rings, is with no absolute hesitation, my most favored and adored book by\u2011far. The triology is wonderful\u2011 and I really consider this a legendary fantasy series. It will always keep you at the edge of your seat\u2011 and the characters you will grow and fall in love with!"
            }, 
        ]));
    }), 
];

;// CONCATENATED MODULE: ./src/mocks/server.ts


const server = (0,node_namespaceObject.setupServer)(...handlers);


/***/ }),

/***/ 7460:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
;// CONCATENATED MODULE: external "styled-reset"
const external_styled_reset_namespaceObject = require("styled-reset");
var external_styled_reset_default = /*#__PURE__*/__webpack_require__.n(external_styled_reset_namespaceObject);
;// CONCATENATED MODULE: ./src/styles/GlobalStyle.tsx


const globalStyle = external_styled_components_.css`
  ${(external_styled_reset_default())}

  @font-face {
    font-family: 'SpoqaBold';
    src: local('Spoqa Han Sans Neo Bold'),
      url('/assets/fonts/SpoqaHanSansNeo-Bold.woff2') format('woff2'),
      url('/assets/fonts/SpoqaHanSansNeo-Bold.woff') format('woff');
    font-display: fallback;
  }

  @font-face {
    font-family: 'Spoqa';
    src: local('Spoqa Han Sans Neo Regular'),
      url('/assets/fonts/SpoqaHanSansNeo-Regular.woff2') format('woff2'),
      url('/assets/fonts/SpoqaHanSansNeo-Regular.woff') format('woff');
    font-display: fallback;
  }

  body {
    font-family: 'Spoqa', 'sans-serif';
  }
  * {
    box-sizing: border-box;
  }
`;
const GlobalStyle = external_styled_components_.createGlobalStyle`
  ${globalStyle};
`;
/* harmony default export */ const styles_GlobalStyle = (GlobalStyle);

// EXTERNAL MODULE: ./src/modules/index.ts + 5 modules
var modules = __webpack_require__(9219);
;// CONCATENATED MODULE: ./src/mocks/index.ts
const initMockApi = ()=>{
    if (true) {
        const { server  } = __webpack_require__(4074);
        console.log("server open \uD83D\uDD25");
        server.listen();
    } else {}
};
/* harmony default export */ const mocks = (initMockApi);

;// CONCATENATED MODULE: ./src/pages/_app.tsx




if (process.env.NEXT_PUBLIC_API_MOCKING === "enabled") {
    mocks();
}
const app = ({ Component , pageProps  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(styles_GlobalStyle, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        ]
    });
};
/* harmony default export */ const _app = (modules/* wrapper.withRedux */.YS.withRedux(app));


/***/ }),

/***/ 6358:
/***/ ((module) => {

module.exports = require("@redux-saga/core");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 5648:
/***/ ((module) => {

module.exports = require("next-redux-wrapper");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("redux");

/***/ }),

/***/ 173:
/***/ ((module) => {

module.exports = require("redux-devtools-extension");

/***/ }),

/***/ 6477:
/***/ ((module) => {

module.exports = require("redux-saga/effects");

/***/ }),

/***/ 7518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 2262:
/***/ ((module) => {

module.exports = require("typesafe-actions");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [219], () => (__webpack_exec__(7460)));
module.exports = __webpack_exports__;

})();