"use strict";
(() => {
var exports = {};
exports.id = 800;
exports.ids = [800];
exports.modules = {

/***/ 1152:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _id_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/modules/index.ts + 5 modules
var modules = __webpack_require__(9219);
;// CONCATENATED MODULE: external "redux-saga"
const external_redux_saga_namespaceObject = require("redux-saga");
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: ./src/components/chatting/Header.tsx





const Header = ()=>{
    const { chatRoomInfo  } = (0,external_react_redux_.useSelector)((state)=>state.chattingRoomState
    );
    return /*#__PURE__*/ jsx_runtime_.jsx(Wrap, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ContentWrap, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/assets/images/prevbtn.svg",
                    alt: "prev button",
                    width: 14,
                    height: 24
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(StyledImage, {
                    src: "/buger.png",
                    width: 44,
                    height: 44
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Div, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Info, {
                            name: "title",
                            children: chatRoomInfo.title
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Info, {
                            name: "info",
                            children: [
                                "\uC778\uC6D02\uBA85/",
                                chatRoomInfo.maxCount,
                                "\uBA85"
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const chatting_Header = (Header);
const Wrap = external_styled_components_default().div.withConfig({
    componentId: "sc-1d8590c7-0"
})`
  background: #191919;
  height: 10%;
  width: 100%;
`;
const ContentWrap = external_styled_components_default().div.withConfig({
    componentId: "sc-1d8590c7-1"
})`
  display: flex;
  align-items: center;
  width: 90%;
  height: 100%;
  margin: 0 auto;
  gap: 10px;
`;
const StyledImage = external_styled_components_default()((image_default())).withConfig({
    componentId: "sc-1d8590c7-2"
})`
  display: inline-block;
  border-radius: 10px;
  background: #fff;
`;
const Div = external_styled_components_default().div.withConfig({
    componentId: "sc-1d8590c7-3"
})`
  display: flex;
  flex-direction: column;
  gap: 5px;
`;
const Info = external_styled_components_default().p.withConfig({
    componentId: "sc-1d8590c7-4"
})`
  color: #fff;
  line-height: 20px;
  ${(props)=>props.name === "title" && external_styled_components_.css`
      font-size: 15px;
    `
}
  ${(props)=>props.name === "info" && external_styled_components_.css`
      font-size: 12px;
    `
}
`;

;// CONCATENATED MODULE: ./src/components/chatting/GoInfoBtn.tsx



const GoInfoBtn = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Button, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                children: "\uAC00\uAC8C\uC815\uBCF4 \uBCF4\uB7EC\uAC00\uAE30"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: "/assets/images/nextbtn.svg",
                alt: "icon",
                width: 11,
                height: 16
            })
        ]
    });
};
/* harmony default export */ const chatting_GoInfoBtn = (GoInfoBtn);
const Button = external_styled_components_default().button.withConfig({
    componentId: "sc-9fd4dbdf-0"
})`
  display: flex;
  align-items: center;
  justify-content: space-between;
  outline: none;
  border: none;
  background: #fff;
  padding: 10px 20px;
  width: 88%;
  height: 100%;
  border-radius: 5px;
  box-shadow: 2px 3px 10px rgba(0, 0, 0, 0.06);
  text-align: left;
  box-sizing: border-box;
  cursor: pointer;
  margin: 0 auto;
  font-size: 12px;
`;

;// CONCATENATED MODULE: ./src/hooks/useChat.ts
function useChat() {
    const connect = (stompClient, roomId, setMessageList)=>{
        stompClient.connect({
            chatMain_id: "1",
            sender: "1"
        }, ()=>{
            stompClient.subscribe(`/topic/${roomId}`, (data)=>{
                const newMessage = JSON.parse(data.body);
                setMessageList((prev)=>prev.concat(newMessage)
                );
            }, {
                chatMain_id: "1"
            });
        });
    };
    const onSendMessage = (stompClient, data, setMessage)=>{
        if (stompClient && data) {
            stompClient.send("/app/chat/send", {}, JSON.stringify(data));
        }
        setMessage("");
    };
    const disconnect = (stompClient)=>{
        stompClient.disconnect();
    };
    return {
        connect,
        disconnect,
        onSendMessage
    };
}

;// CONCATENATED MODULE: ./src/components/chatting/SubmitForm.tsx





const SubmitForm = ({ stompClient  })=>{
    const { onSendMessage  } = useChat();
    const { 0: message , 1: setMessage  } = (0,external_react_.useState)("");
    const onSubmit = (e)=>{
        e.preventDefault();
        const data = {
            chatMain_id: 1,
            sender: 1,
            contents: message,
            type: "TEXT"
        };
        onSendMessage(stompClient, data, setMessage);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(SubmitForm_Wrap, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(SubmitForm_ContentWrap, {
            onSubmit: onSubmit,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(ImgAddLabel, {
                    htmlFor: "image",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/assets/images/imgaddbtn.svg",
                        alt: "img add icon",
                        width: 19,
                        height: 24
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(ImgAddBtn, {
                    type: "file",
                    accept: "image/*",
                    id: "image"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Input, {
                    type: "text",
                    value: message,
                    onChange: (e)=>{
                        setMessage(e.target.value);
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(SubmitForm_Button, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/assets/images/submitbtn.svg",
                        alt: "submit button",
                        width: 23,
                        height: 24
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const chatting_SubmitForm = (SubmitForm);
const SubmitForm_Wrap = external_styled_components_default().div.withConfig({
    componentId: "sc-33781815-0"
})`
  background: #fff;
  width: 100%;
  height: 8%;
`;
const SubmitForm_ContentWrap = external_styled_components_default().form.withConfig({
    componentId: "sc-33781815-1"
})`
  display: flex;
  align-items: center;
  width: 90%;
  height: 100%;
  margin: 0 auto;
  justify-content: center;
  gap: 3%;
`;
const Input = external_styled_components_default().input.withConfig({
    componentId: "sc-33781815-2"
})`
  background: #f2f2f8;
  outline: none;
  border: none;
  border-radius: 10px;
  width: 90%;
  height: 70%;
  padding: 0 10px;
`;
const ImgAddLabel = external_styled_components_default().label.withConfig({
    componentId: "sc-33781815-3"
})`
  cursor: pointer;
`;
const ImgAddBtn = external_styled_components_default().input.withConfig({
    componentId: "sc-33781815-4"
})`
  display: none;
`;
const SubmitForm_Button = external_styled_components_default().button.withConfig({
    componentId: "sc-33781815-5"
})`
  outline: none;
  cursor: pointer;
  background: #fff;
  border: none;
`;

;// CONCATENATED MODULE: external "moment"
const external_moment_namespaceObject = require("moment");
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_namespaceObject);
// EXTERNAL MODULE: ./src/styles/palette.ts
var palette = __webpack_require__(6559);
;// CONCATENATED MODULE: ./src/components/chatting/ChatItem.tsx





const ChatItem = ({ message , date  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ChatItem_Wrap, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ChatItem_StyledImage, {
                src: "/buger.png",
                width: 35,
                height: 35,
                layout: "fixed"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Content, {
                children: message.contents
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Time, {
                children: [
                    external_moment_default()().format("YYYYMMDD") === external_moment_default()(date).format("YYYYMMDD") && external_moment_default()(date).format("a") === "am" ? external_moment_default()(date).format("\uC624\uC804 h:mm") : external_moment_default()(date).format("\uC624\uD6C4 h:mm"),
                    external_moment_default()().format("YYYYMMDD") !== external_moment_default()(date).format("YYYYMMDD") && external_moment_default()(date).format("MM/DD")
                ]
            })
        ]
    });
};
/* harmony default export */ const chatting_ChatItem = (ChatItem);
const ChatItem_Wrap = external_styled_components_default().div.withConfig({
    componentId: "sc-f29ac1ca-0"
})`
  width: 100%;
  display: flex;
  margin-left: 10px;
  gap: 5px;
  align-items: flex-end;
`;
const ChatItem_StyledImage = external_styled_components_default()((image_default())).withConfig({
    componentId: "sc-f29ac1ca-1"
})`
  background: ${palette/* default.DarkGray */.Z.DarkGray};
  border-radius: 10px 10px 0px 10px;
  object-fit: cover;
`;
const Content = external_styled_components_default().p.withConfig({
    componentId: "sc-f29ac1ca-2"
})`
  background: ${palette/* default.mainOrange */.Z.mainOrange};
  font-size: 15px;
  border-radius: 10px 10px 10px 0px;
  align-items: flex-start;
  padding: 6px 10px;
  line-height: 22.5px;
  max-width: 80%;
  color: #fff;
`;
const Time = external_styled_components_default().p.withConfig({
    componentId: "sc-f29ac1ca-3"
})`
  color: ${palette/* default.DarkGray */.Z.DarkGray};
  font-size: 12px;
`;

;// CONCATENATED MODULE: ./src/hooks/useSlideMessage.ts
function useSlideMessage() {
    const slideEvent = (slideBar, target)=>{
        let initialY = 0;
        let currentY = 0;
        const grabDown = (e)=>{
            initialY = e.pageY;
        };
        const grabMove = (e)=>{
            if (initialY <= 0) return;
            currentY = e.pageY;
            if (currentY > initialY) {
                target.current.style.height = `${200 - (currentY - initialY)}px`;
                if (currentY - initialY > 50) {
                    target.current.style.height = "30px";
                    initialY = 0;
                    currentY = 0;
                }
            } else {
                target.current.style.height = `${30 + (initialY - currentY)}px`;
                if (initialY - currentY > 50) {
                    target.current.style.height = "200px";
                    initialY = 0;
                    currentY = 0;
                }
            }
        };
        if (window.PointerEvent) {
            slideBar.current.addEventListener("pointerdown", grabDown);
            slideBar.current.addEventListener("pointermove", grabMove);
        } else {
            slideBar.current.addEventListener("mousedown", grabDown);
            slideBar.current.addEventListener("mousemove", grabMove);
        }
        return ()=>{
            if (window.PointerEvent) {
                slideBar.current.removeEventListener("pointerdown", grabDown);
                slideBar.current.removeEventListener("pointermove", grabMove);
            } else {
                slideBar.current.removeEventListener("mousedown", grabDown);
                slideBar.current.removeEventListener("mousemove", grabMove);
            }
        };
    };
    return {
        slideEvent
    };
}

;// CONCATENATED MODULE: ./src/components/chatting/QuickMessageComp.tsx






const QuickMessageComp = ()=>{
    const target = (0,external_react_.useRef)(null);
    const slideBar = (0,external_react_.useRef)(null);
    const { slideEvent  } = useSlideMessage();
    (0,external_react_.useEffect)(()=>{
        slideEvent(slideBar, target);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(QuickMessageComp_Wrap, {
        ref: target,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(QuickMessageComp_Div, {
                ref: slideBar,
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/assets/images/slidedown.svg",
                    alt: "icon",
                    width: 36,
                    height: 3
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Item, {
                children: "\uC548\uB155\uD558\uC138\uC694. \uC9C0\uAE08 \uC8FC\uBB38 \uAC00\uB2A5\uD558\uC2E0\uAC00\uC694?"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Item, {
                children: "\uBC31\uC11D\uACE0\uB4F1\uD559\uAD50 \uC815\uBB38 \uC55E\uC5D0\uC11C \uB9CC\uB098\uACE0 \uC2F6\uC2B5\uB2C8\uB2E4."
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Item, {
                children: "\uC7A0\uC2DC \uBA54\uB274\uB97C \uACE0\uB974\uACA0\uC2B5\uB2C8\uB2E4. 2\uBD84\uB9CC \uAE30\uB2E4\uB824\uC8FC\uC138\uC694!"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(EditBtn, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "\uD3B8\uC9D1\uD558\uAE30"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/assets/images/setting.svg",
                        alt: "setting icon",
                        width: 15,
                        height: 20
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const chatting_QuickMessageComp = (QuickMessageComp);
const QuickMessageComp_Wrap = external_styled_components_default().div.withConfig({
    componentId: "sc-1ae9f0bd-0"
})`
  width: 100%;
  max-height: 200px;
  background: #fff;
  overflow: hidden;
  position: fixed;
  bottom: 8%;
  border-radius: 20px 20px 0px 0px;
  padding: 0 6% 14px;
  touch-action: none;
  & > img {
    display: block;
    margin: 0 auto;
  }
  border-bottom: 1px solid ${palette/* default.LineGray */.Z.LineGray};
`;
const QuickMessageComp_Div = external_styled_components_default().div.withConfig({
    componentId: "sc-1ae9f0bd-1"
})`
  padding-top: 10px;
  padding-bottom: 22px;
  text-align: center;
  cursor: grab;
  touch-action: none;
`;
const Item = external_styled_components_default().p.withConfig({
    componentId: "sc-1ae9f0bd-2"
})`
  font-size: 15px;
  line-height: 20px;
  margin-bottom: 22px;
  cursor: pointer;
`;
const EditBtn = external_styled_components_default().button.withConfig({
    componentId: "sc-1ae9f0bd-3"
})`
  color: #ef6212;
  outline: none;
  border: none;
  font-size: 12px;
  background: transparent;
  cursor: pointer;
  display: flex;
  gap: 3px;
  align-items: center;
  padding: 0;
`;

;// CONCATENATED MODULE: ./src/components/chatting/MyChatItem.tsx




const MyChatItem = ({ message , date  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MyChatItem_Wrap, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MyChatItem_Time, {
                children: [
                    external_moment_default()().format("YYYYMMDD") === external_moment_default()(date).format("YYYYMMDD") && external_moment_default()(date).format("a") === "am" ? external_moment_default()(date).format("\uC624\uC804 h:mm") : external_moment_default()(date).format("\uC624\uD6C4 h:mm"),
                    external_moment_default()().format("YYYYMMDD") !== external_moment_default()(date).format("YYYYMMDD") && external_moment_default()(date).format("MM/DD")
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(MyChatItem_Content, {
                children: message.contents
            })
        ]
    });
};
/* harmony default export */ const chatting_MyChatItem = (MyChatItem);
const MyChatItem_Wrap = external_styled_components_default().div.withConfig({
    componentId: "sc-a83ead36-0"
})`
  display: flex;
  gap: 5px;
  justify-content: end;
  align-items: flex-end;
  margin-right: 10px;
  width: 100%;
`;
const MyChatItem_Time = external_styled_components_default().p.withConfig({
    componentId: "sc-a83ead36-1"
})`
  color: ${palette/* default.DarkGray */.Z.DarkGray};
  font-size: 12px;
`;
const MyChatItem_Content = external_styled_components_default().p.withConfig({
    componentId: "sc-a83ead36-2"
})`
  background: #fff;
  font-size: 15px;
  border-radius: 10px 10px 0px 10px;
  align-items: flex-start;
  padding: 6px 10px;
  line-height: 1.2em;
  max-width: 80%;
`;

;// CONCATENATED MODULE: external "@stomp/stompjs"
const stompjs_namespaceObject = require("@stomp/stompjs");
;// CONCATENATED MODULE: external "sockjs-client"
const external_sockjs_client_namespaceObject = require("sockjs-client");
var external_sockjs_client_default = /*#__PURE__*/__webpack_require__.n(external_sockjs_client_namespaceObject);
;// CONCATENATED MODULE: ./src/components/chatting/ChattingTemplate.tsx














const ChattingTemplate = ()=>{
    const { 0: messageList , 1: setMessageList  } = (0,external_react_.useState)([]);
    const { previousChatting  } = (0,external_react_redux_.useSelector)((state)=>state.chattingRoomState
    );
    const socket = new (external_sockjs_client_default())(`${process.env.NEXT_PUBLIC_API_URL}/chat`);
    const stompClient = stompjs_namespaceObject.Stomp.over(socket);
    const { connect , disconnect  } = useChat();
    (0,external_react_.useEffect)(()=>{
        if (!stompClient.connected) {
            connect(stompClient, 1, setMessageList); // 1은 채팅방 아이디
        }
        return ()=>disconnect(stompClient)
        ;
    }, [
        stompClient,
        messageList
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ChattingTemplate_Wrap, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(chatting_Header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(ChattingTemplate_Div, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(chatting_GoInfoBtn, {})
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ChattingTemplate_Content, {
                children: [
                    previousChatting.messages && previousChatting.messages.length > 0 && previousChatting.messages.map((message, i)=>{
                        if (message.user_id === 1) {
                            // 1은 내 아이디
                            // 내 아이디랑 같으면
                            return /*#__PURE__*/ jsx_runtime_.jsx(chatting_MyChatItem, {
                                message: message,
                                date: message.regDate
                            }, i);
                        } else {
                            return /*#__PURE__*/ jsx_runtime_.jsx(chatting_ChatItem, {
                                message: message,
                                date: message.regDate
                            }, i);
                        }
                    }),
                    messageList && messageList.length > 0 && messageList.map((message, i)=>{
                        if (message.sender === 1) {
                            // 내 아이디랑 같으면
                            return /*#__PURE__*/ jsx_runtime_.jsx(chatting_MyChatItem, {
                                message: message,
                                date: external_moment_default()().format()
                            }, i);
                        } else {
                            return /*#__PURE__*/ jsx_runtime_.jsx(chatting_ChatItem, {
                                message: message,
                                date: external_moment_default()().format()
                            }, i);
                        }
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(chatting_QuickMessageComp, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(chatting_SubmitForm, {
                stompClient: stompClient,
                setMessageList: setMessageList
            })
        ]
    });
};
/* harmony default export */ const chatting_ChattingTemplate = (ChattingTemplate);
const ChattingTemplate_Wrap = external_styled_components_default().div.withConfig({
    componentId: "sc-fcb17092-0"
})`
  width: 100vw;
  height: 100vh;
  background: #f2f2f8;
  overflow: hidden;
`;
const ChattingTemplate_Div = external_styled_components_default().div.withConfig({
    componentId: "sc-fcb17092-1"
})`
  width: 100%;
  height: 10%;
  padding: 10px 0 18px;
`;
const ChattingTemplate_Content = external_styled_components_default().div.withConfig({
    componentId: "sc-fcb17092-2"
})`
  width: 100%;
  margin: 0 auto;
  height: 72%;
  padding-bottom: 30px;
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 15px;
  overflow-y: auto;
  overflow-x: hidden;
`;

// EXTERNAL MODULE: ./src/modules/chatting/actions.ts
var actions = __webpack_require__(7854);
;// CONCATENATED MODULE: ./src/pages/chatting/[id].tsx





const chatting = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(chatting_ChattingTemplate, {});
};
const getServerSideProps = modules/* wrapper.getServerSideProps */.YS.getServerSideProps((store)=>async (context)=>{
        store.dispatch(actions/* getCurrentChatRoomAsyncActions.request */.xl.request({
            chattingRoomId: Number(context.params.id)
        }));
        store.dispatch(actions/* getPreviousChattingListActions.request */.qh.request({
            chattingRoomId: Number(context.params.id),
            userId: 1
        }));
        store.dispatch(external_redux_saga_namespaceObject.END);
        await store.sagaTask.toPromise();
        return {
            props: {}
        };
    }
);
/* harmony default export */ const _id_ = (chatting);


/***/ }),

/***/ 6559:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    black: "#191919",
    DarkGray: "#696969",
    Gray: "#c9c9c9",
    LineGray: "#E0E0E0",
    LightGray: "#EBEBEB",
    bgGray: "#f2f2f8",
    mainOrange: "#FF7B30",
    kakaoYellow: "#FFE812",
    naverGreen: "#03C75A"
});


/***/ }),

/***/ 6358:
/***/ ((module) => {

module.exports = require("@redux-saga/core");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 5648:
/***/ ((module) => {

module.exports = require("next-redux-wrapper");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("redux");

/***/ }),

/***/ 173:
/***/ ((module) => {

module.exports = require("redux-devtools-extension");

/***/ }),

/***/ 6477:
/***/ ((module) => {

module.exports = require("redux-saga/effects");

/***/ }),

/***/ 7518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 2262:
/***/ ((module) => {

module.exports = require("typesafe-actions");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [686,675,219], () => (__webpack_exec__(1152)));
module.exports = __webpack_exports__;

})();