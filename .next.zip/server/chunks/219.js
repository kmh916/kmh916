"use strict";
exports.id = 219;
exports.ids = [219];
exports.modules = {

/***/ 7854:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GM": () => (/* binding */ GET_CURRENT_CHATROOM_INFO_SUCCESS),
/* harmony export */   "Wp": () => (/* binding */ GET_PREVIOUS_CHATTING_LIST_SUCCESS),
/* harmony export */   "om": () => (/* binding */ GET_CURRENT_CHATROOM_INFO_REQUEST),
/* harmony export */   "pW": () => (/* binding */ GET_PREVIOUS_CHATTING_LIST_REQUEST),
/* harmony export */   "qh": () => (/* binding */ getPreviousChattingListActions),
/* harmony export */   "xl": () => (/* binding */ getCurrentChatRoomAsyncActions)
/* harmony export */ });
/* unused harmony exports GET_CURRENT_CHATROOM_INFO_FAILURE, GET_PREVIOUS_CHATTING_LIST_FAILURE */
/* harmony import */ var typesafe_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2262);
/* harmony import */ var typesafe_actions__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(typesafe_actions__WEBPACK_IMPORTED_MODULE_0__);

const namespace = "chatting/";
const GET_CURRENT_CHATROOM_INFO_REQUEST = namespace + "GET_CURRENT_CHATROOM_INFO_REQUEST";
const GET_CURRENT_CHATROOM_INFO_SUCCESS = namespace + "GET_CURRENT_CHATROOM_INFO_SUCCESS";
const GET_CURRENT_CHATROOM_INFO_FAILURE = namespace + "GET_CURRENT_CHATROOM_INFO_FAILURE";
const GET_PREVIOUS_CHATTING_LIST_REQUEST = namespace + "GET_PREVIOUS_CHATTING_LIST_REQUEST";
const GET_PREVIOUS_CHATTING_LIST_SUCCESS = namespace + "GET_PREVIOUS_CHATTING_LIST_SUCCESS";
const GET_PREVIOUS_CHATTING_LIST_FAILURE = namespace + "GET_PREVIOUS_CHATTING_LIST_FAILURE";
// action creators
const getCurrentChatRoomAsyncActions = (0,typesafe_actions__WEBPACK_IMPORTED_MODULE_0__.createAsyncAction)(GET_CURRENT_CHATROOM_INFO_REQUEST, GET_CURRENT_CHATROOM_INFO_SUCCESS, GET_CURRENT_CHATROOM_INFO_FAILURE)();
const getPreviousChattingListActions = (0,typesafe_actions__WEBPACK_IMPORTED_MODULE_0__.createAsyncAction)(GET_PREVIOUS_CHATTING_LIST_REQUEST, GET_PREVIOUS_CHATTING_LIST_SUCCESS, GET_PREVIOUS_CHATTING_LIST_FAILURE)();


/***/ }),

/***/ 9219:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "YS": () => (/* binding */ wrapper)
});

// UNUSED EXPORTS: configureStore, rootReducer, rootSaga

// EXTERNAL MODULE: external "@redux-saga/core"
var core_ = __webpack_require__(6358);
var core_default = /*#__PURE__*/__webpack_require__.n(core_);
// EXTERNAL MODULE: external "next-redux-wrapper"
var external_next_redux_wrapper_ = __webpack_require__(5648);
// EXTERNAL MODULE: external "redux"
var external_redux_ = __webpack_require__(6695);
// EXTERNAL MODULE: external "redux-saga/effects"
var effects_ = __webpack_require__(6477);
// EXTERNAL MODULE: external "redux-devtools-extension"
var external_redux_devtools_extension_ = __webpack_require__(173);
// EXTERNAL MODULE: ./src/modules/chatting/actions.ts
var actions = __webpack_require__(7854);
// EXTERNAL MODULE: external "typesafe-actions"
var external_typesafe_actions_ = __webpack_require__(2262);
;// CONCATENATED MODULE: ./src/modules/chatting/reducer.ts


const initialChattingRoomState = {
    chatRoomInfo: null,
    previousChatting: {
        messages: []
    }
};
const chattingRoomState = (0,external_typesafe_actions_.createReducer)(initialChattingRoomState, {
    [actions/* GET_CURRENT_CHATROOM_INFO_SUCCESS */.GM]: (state, action)=>({
            ...state,
            chatRoomInfo: action.payload
        })
    ,
    [actions/* GET_PREVIOUS_CHATTING_LIST_SUCCESS */.Wp]: (state, action)=>({
            ...state,
            previousChatting: action.payload
        })
});

// EXTERNAL MODULE: ./src/modules/search-post-code/actions.ts
var search_post_code_actions = __webpack_require__(6445);
;// CONCATENATED MODULE: ./src/modules/search-post-code/reducer.ts


const initialPostCodeState = {
    address: "",
    buildingName: "",
    buildingCode: "",
    apartment: ""
};
const postCodeState = (0,external_typesafe_actions_.createReducer)(initialPostCodeState, {
    [search_post_code_actions/* SAVE_ADDRESS_WITH_BUILDING_CODE */.U]: (state, action)=>({
            ...state,
            address: action.payload.address,
            buildingName: action.payload.buildingName,
            buildingCode: action.payload.buildingCode,
            apartment: action.payload.apartment
        })
});

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
;// CONCATENATED MODULE: ./src/service/api/index.ts

const axiosInstance = external_axios_default().create({
    baseURL: process.env.NEXT_PUBLIC_API_URL
});
class ApiService {
    static getApi(uri) {
        return axiosInstance.get(`${uri}`);
    }
    static postApi(uri, data) {
        return axiosInstance.post(`${uri}`, data);
    }
}

;// CONCATENATED MODULE: ./src/service/api/chatting/ChattingService.ts

class ChattingService {
    static async asyncGetChattingRoomInfo(chattingRoomId) {
        try {
            const res = await ApiService.getApi(`/chat/rooms/${chattingRoomId}`);
            return res;
        } catch (err) {
            console.log(err);
        }
    }
    static async asyncGetPreviousChattingList(chattingRoomId, userId) {
        try {
            return await ApiService.getApi(`/chat/messages/${chattingRoomId}/${userId}`);
        } catch (err) {
            console.log(err);
        }
    }
};

;// CONCATENATED MODULE: ./src/modules/chatting/sagas.ts



function* getChattingRoomInfoGenerator(action) {
    const { data  } = yield (0,effects_.call)(ChattingService.asyncGetChattingRoomInfo, action.payload.chattingRoomId);
    yield (0,effects_.put)(actions/* getCurrentChatRoomAsyncActions.success */.xl.success(data));
}
function* getPreviousChattingListGenerator(action) {
    const { data  } = yield (0,effects_.call)(ChattingService.asyncGetPreviousChattingList, action.payload.chattingRoomId, action.payload.userId);
    yield (0,effects_.put)(actions/* getPreviousChattingListActions.success */.qh.success(data));
}
function* getChattingRoomInfoSaga() {
    yield* [
        (0,effects_.takeLatest)(actions/* GET_CURRENT_CHATROOM_INFO_REQUEST */.om, getChattingRoomInfoGenerator),
        (0,effects_.takeLatest)(actions/* GET_PREVIOUS_CHATTING_LIST_REQUEST */.pW, getPreviousChattingListGenerator), 
    ];
}

;// CONCATENATED MODULE: ./src/modules/index.ts








//** RootReducer */
const rootReducer = (0,external_redux_.combineReducers)({
    chattingRoomState: chattingRoomState,
    postCodeState: postCodeState
});
//** RootSaga */
function* rootSaga() {
    yield (0,effects_.all)([
        (0,effects_.fork)(getChattingRoomInfoSaga)
    ]);
}
//** Hydrate */
const reducer = (state, action)=>{
    if (action.type === external_next_redux_wrapper_.HYDRATE) {
        const nextState = {
            ...state,
            ...action.payload
        };
        return nextState;
    }
    return rootReducer(state, action);
};
const configureStore = ()=>{
    const sagaMiddleware = core_default()();
    const middlewares = [
        sagaMiddleware
    ];
    const enhancer = (0,external_redux_devtools_extension_.composeWithDevTools)((0,external_redux_.applyMiddleware)(...middlewares));
    const store = (0,external_redux_.createStore)(reducer, enhancer);
    store.sagaTask = sagaMiddleware.run(rootSaga);
    return store;
};
const wrapper = (0,external_next_redux_wrapper_.createWrapper)(configureStore, {
    debug: true
});


/***/ }),

/***/ 6445:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ SAVE_ADDRESS_WITH_BUILDING_CODE),
/* harmony export */   "c": () => (/* binding */ saveAddresWithBuildingCode)
/* harmony export */ });
/* harmony import */ var typesafe_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2262);
/* harmony import */ var typesafe_actions__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(typesafe_actions__WEBPACK_IMPORTED_MODULE_0__);

const namespace = "search-post-code/";
const SAVE_ADDRESS_WITH_BUILDING_CODE = namespace + "SAVE_ADDRESS_WITH_BUILDING_CODE";
const saveAddresWithBuildingCode = (0,typesafe_actions__WEBPACK_IMPORTED_MODULE_0__.createAction)(SAVE_ADDRESS_WITH_BUILDING_CODE, (data)=>data
)();


/***/ })

};
;